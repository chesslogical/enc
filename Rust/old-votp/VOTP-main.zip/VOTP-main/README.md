# votp 2.0 — Versatile, Hardened One‑Time‑Pad XOR Utility

`votp` is a single‑binary Rust CLI that does **everything you could reasonably want from a file‑based one‑time‑pad tool**:

| Capability                  | Detail                                                              |
| --------------------------- | ------------------------------------------------------------------- |
| **Streaming XOR**           | 64 KiB constant RAM; handles multi‑GB files easily                  |
| **Atomic in‑place mode**    | Temp‑file → `fsync` → atomic `rename()` (POSIX & Windows)           |
| **Safety knobs**            | `--min-len` (key ≥ data) · `--strict-len` (key = data)              |
| **Crash durability**        | `sync_all()` on temp + parent dir before rename                     |
| **Metadata cloning**        | POSIX mode bits, timestamps, optional **xattrs** (feature `xattrs`) |
| **Exclusive file lock**     | Prevents concurrent readers/writers while working                   |
| **Memory hygiene**          | All plaintext & keystream slices are wiped with `zeroize`           |
| **Integrity check**         | Opt‑in SHA‑256 verify/print (`--features verify`)                   |
| **Flexible I/O**            | File ↔ file, stdin ↔ stdout, or true in‑place overwrite             |
| **Environment convenience** | Key path fallback `$OTP_KEY`, default `key.key`                     |

---

## 1  Installation

```bash
# Lean binary
cargo build --release           # ./target/release/votp

# With SHA‑256 verification
cargo build --release --features verify

# With verification + extended attributes on Unix
cargo build --release --features "verify xattrs"
```

Copy or symlink `target/release/votp` into your `$PATH`.

---

## 2  Basic usage

```text
votp --help
```

```
USAGE:
    votp -i <INPUT> [-k <KEY>] [-o <OUTPUT>] [--in-place]
         [--min-len | --strict-len]
         [--expect <HEX>]      # (requires --features verify)
```

| Flag                  | Meaning                                                     |
| --------------------- | ----------------------------------------------------------- |
| `-i, --input <FILE>`  | Plaintext / ciphertext (use `-` for **STDIN**)              |
| `-k, --key <FILE>`    | Key file (defaults to `$OTP_KEY` then `key.key`)            |
| `-o, --output <FILE>` | Output file (use `-` for **STDOUT**)                        |
| `--in-place`          | Atomically overwrite input file (conflicts with `--output`) |
| `--min-len`           | Reject if key **shorter** than data                         |
| `--strict-len`        | Reject unless key **exactly equals** data length            |
| `--expect <HEX>`      | Verify SHA‑256 after write *(feature `verify`)*             |

---

## 3  Round‑trip examples

Assume `example.txt` is plaintext and `key.bin` is a random key:

### 3.1 Separate output file (Linux/macOS shell)

```bash
# Encrypt
./votp -i example.txt -k key.bin -o example2.txt

# Decrypt
./votp -i example2.txt -k key.bin -o example3.txt
```

### 3.2 In‑place encryption (Windows PowerShell shown)

```powershell
Copy-Item example.txt example2.txt           # working copy
.\votp.exe -i example2.txt -k key.bin --in-place
.\votp.exe -i example2.txt -k key.bin -o example3.txt
```

### 3.3 Pure streaming pipeline

```bash
cat example.txt | ./votp -i - -k key.bin -o example2.txt
cat example2.txt | ./votp -i - -k key.bin -o example3.txt
```

---

## 4  Integrity verification (opt‑in)

```bash
cargo build --release --features verify
./votp -i secret.pdf -k onetime.key -o secret.enc --expect d2c7...
```

*With `--expect HEX`* the program exits non‑zero if the final SHA‑256 differs.
*Without `--expect`* it prints the digest to stderr when stderr is a TTY.

---

## 5  Extended attributes (Unix, opt‑in)

```bash
cargo build --release --features "verify xattrs"
./votp ...               # copies SELinux labels, Apple extended attributes, etc.
```

---

## 6  Security checklist

1. **Generate keys with a CSPRNG** (`dd if=/dev/urandom`, `openssl rand`, etc.).
2. For information‑theoretic security, **key length ≥ plaintext length**
   (`--min-len` or `--strict-len` enforce this).
3. **Never reuse** a key.
4. Transport and store key material with equal or better security than the data.
5. In‑place mode syncs to disk and is atomic, but true durability still relies on
   correct hardware (write‑barriers, journalling, UPS).

---

## 7  License

Dual‑licensed under **MIT** or **Apache‑2.0** — choose either.

---

*Built by CHATGPT with ❤️ and paranoia — enjoy your versatile OTP!*
