//! votp 2.0 – Versatile, production‑grade One‑Time‑Pad XOR transformer.
//!
//! Build examples
//!   cargo build --release
//!   cargo build --release --features verify
//!   cargo build --release --features "verify xattrs"

use anyhow::{anyhow, bail, Context, Result};
use clap::Parser;
use fs2::FileExt;
use std::{
    fs::{self, File, OpenOptions},
    io::{Read, Seek, SeekFrom, Write},
    path::PathBuf,
    time::Instant,
};
use tempfile::Builder;
use zeroize::Zeroize;

#[cfg(feature = "verify")]
use sha2::{Digest, Sha256};
#[cfg(feature = "verify")]
use atty;

#[cfg(unix)]
use filetime::{set_file_times, FileTime};

const BUF_CAP: usize = 64 * 1024;     // 64 KiB streaming buffers
const TMP_PREFIX: &str = ".votp-tmp-";

/// Command‑line interface --------------------------------------------------
#[derive(Parser, Debug)]
#[command(author, version, about)]
struct Args {
    /// Input file (use '-' for STDIN; '--in-place' forbidden with STDIN)
    #[arg(short, long)]
    input: PathBuf,

    /// Key file (falls back to $OTP_KEY, then 'key.key')
    #[arg(short, long)]
    key: Option<PathBuf>,

    /// Output file (use '-' for STDOUT). Ignored with --in-place.
    #[arg(short, long)]
    output: Option<PathBuf>,

    /// Encrypt/decrypt in place (atomic replace of INPUT)
    #[arg(long, conflicts_with = "output")]
    in_place: bool,

    /// Require key length ≥ data length (refuse short‑key mode)
    #[arg(long, conflicts_with = "strict_len")]
    min_len: bool,

    /// Require key length == data length (classical OTP discipline)
    #[arg(long)]
    strict_len: bool,

    /// Print SHA‑256 of result or compare to EXPECT (needs --features verify)
    #[cfg(feature = "verify")]
    #[arg(long)]
    expect: Option<String>,
}

fn main() -> Result<()> {
    let t0 = Instant::now();
    let args = Args::parse();

    /* ───────────── Resolve key path ───────────── */
    let key_path = args
        .key
        .or_else(|| std::env::var_os("OTP_KEY").map(PathBuf::from))
        .unwrap_or_else(|| PathBuf::from("key.key"));

    /* ───────────── Basic file metadata ────────── */
    let src_meta = fs::metadata(&args.input)
        .with_context(|| format!("reading metadata for '{}'", args.input.display()))?;
    let data_len = src_meta.len();

    let key_len = fs::metadata(&key_path)
        .with_context(|| format!("reading metadata for key '{}'", key_path.display()))?
        .len();

    if args.strict_len && key_len != data_len {
        bail!(
            "--strict-len: key length {} ≠ data length {}",
            key_len,
            data_len
        );
    }
    if args.min_len && key_len < data_len {
        bail!(
            "--min-len: key length {} < data length {}",
            key_len,
            data_len
        );
    }

    /* ───────────── Prepare streams ────────────── */

    // ---- Key reader ------------------------------------------------------
    let mut key_file = File::open(&key_path)
        .with_context(|| format!("opening key '{}'", key_path.display()))?;

    // ---- Output destination ---------------------------------------------
    let (mut writer, tmp_path): (Box<dyn Write>, Option<PathBuf>) = if args.in_place {
        if args.input == PathBuf::from("-") {
            bail!("--in-place cannot be used with STDIN");
        }
        let dir = args
            .input
            .parent()
            .ok_or_else(|| anyhow!("cannot determine parent directory of input"))?;
        let tmp = Builder::new()
            .prefix(TMP_PREFIX)
            .tempfile_in(dir)
            .context("creating temporary file")?;

        fs::set_permissions(tmp.path(), src_meta.permissions())
            .context("copying permissions to temp file")?;

        let (handle, path) = tmp.keep().context("persisting temporary file")?;
        (Box::new(handle), Some(path))
    } else {
        let out_path = args
            .output
            .clone()
            .ok_or_else(|| anyhow!("--output or --in-place must be supplied"))?;
        if out_path == PathBuf::from("-") {
            (Box::new(std::io::stdout().lock()), None)
        } else {
            let f = File::create(&out_path)
                .with_context(|| format!("creating output '{}'", out_path.display()))?;
            (Box::new(f), None)
        }
    };

    // ---- Input reader ----------------------------------------------------
    let mut reader: Box<dyn Read> = if args.input == PathBuf::from("-") {
        Box::new(std::io::stdin().lock())
    } else {
        let f = OpenOptions::new()
            .read(true)
            .open(&args.input)
            .with_context(|| format!("opening input '{}'", args.input.display()))?;
        f.lock_exclusive()
            .with_context(|| "locking input file for exclusive access")?;
        Box::new(f)
    };

    /* ───────────── Streaming XOR loop ─────────── */
    let mut data_buf = vec![0u8; BUF_CAP];
    let mut key_buf = vec![0u8; BUF_CAP];
    loop {
        let n = reader.read(&mut data_buf)?;
        if n == 0 {
            break;
        }
        fill_key_slice(&mut key_file, &mut key_buf[..n])?;
        for (d, k) in data_buf[..n].iter_mut().zip(&key_buf[..n]) {
            *d ^= *k;
        }
        writer.write_all(&data_buf[..n])?;

        data_buf[..n].zeroize();
        key_buf[..n].zeroize();
    }
    writer.flush()?;

    /* ───────────── Durability fences ──────────── */
    if let Some(ref tmp) = tmp_path {
        let f = OpenOptions::new().write(true).open(tmp)?;
        f.sync_all()?;
        if let Some(parent) = tmp.parent() {
            if let Ok(d) = File::open(parent) {
                let _ = d.sync_all();
            }
        }
    }

    /* ───────────── In‑place finalisation ──────── */
    if let Some(tmp) = tmp_path {
        #[cfg(windows)]
        {
            let mut perms = fs::metadata(&args.input)?.permissions();
            if perms.readonly() {
                perms.set_readonly(false);
                fs::set_permissions(&args.input, perms)?;
            }
        }
        fs::rename(&tmp, &args.input).context("atomic rename failed")?;

        #[cfg(unix)]
        {
            let atime = FileTime::from_last_access_time(&src_meta);
            let mtime = FileTime::from_last_modification_time(&src_meta);
            set_file_times(&args.input, atime, mtime)
                .context("restoring timestamps")?;

            #[cfg(feature = "xattrs")]
            for attr in xattr::list(&key_path).unwrap_or_default() {
                if let Some(val) = xattr::get(&key_path, &attr).unwrap_or(None) {
                    let _ = xattr::set(&args.input, &attr, &val);
                }
            }
        }
    }

    /* ───────────── Optional SHA‑256 verify ───── */
    #[cfg(feature = "verify")]
    {
        let path_to_check: PathBuf = if args.in_place {
            args.input.clone()
        } else {
            args.output
                .clone()
                .expect("output path validated earlier")
        };
        let mut file = File::open(&path_to_check)?;
        let mut hasher = Sha256::new();
        let mut buf = [0u8; BUF_CAP];
        loop {
            let m = file.read(&mut buf)?;
            if m == 0 {
                break;
            }
            hasher.update(&buf[..m]);
        }
        let digest = format!("{:x}", hasher.finalize());

        match args.expect {
            Some(expected) => {
                if digest.to_lowercase() != expected.to_lowercase() {
                    bail!("SHA‑256 mismatch! expected {expected}, got {digest}");
                }
                eprintln!("✓ SHA‑256 verified");
            }
            None => {
                if atty::is(atty::Stream::Stderr) {
                    eprintln!("SHA‑256(output) = {digest}");
                }
            }
        }
    }

    eprintln!("✓ done in {:.2?}", t0.elapsed());
    Ok(())
}

/* ───────────────────────── helpers ─────────────────────────────── */

/// Fill `dest` completely with bytes from `key`, rewinding on EOF.
fn fill_key_slice<R: Read + Seek>(key: &mut R, dest: &mut [u8]) -> Result<()> {
    let mut filled = 0;
    while filled < dest.len() {
        let n = key.read(&mut dest[filled..])?;
        if n == 0 {
            key.seek(SeekFrom::Start(0))?;
            continue;
        }
        filled += n;
    }
    Ok(())
}
